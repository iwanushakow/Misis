var numero = 2;
document.write(numero)
from flask import Flask, redirect, render_template, request, send_file
import importlib
from nuero_network import nuero_network as nn

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
app.config['UPLOAD_FOLDER'] = 'works'
dude = importlib.import_module('nuero_network')

numero = 3
nuerons_list = [7]

@app.route('/', methods=['GET', 'POST'])
def main():
    global numero, nuerons_list
    marker = False
    accuracy = 'not calculated'
    if request.method == 'GET':
        dictionary = dict(request.args)
        if len(dictionary) > 0:
            for i in dictionary.keys():
                if 'add' in i:
                    numero += 1
                    nuerons_list.append(7)
                if 'sub' in i and numero > 2:
                    numero -= 1
                    nuerons_list = nuerons_list[:-1]
                if 'start' in i:
                    lst = [i for i in nuerons_list]
                    lst.append(3)
                    lst.insert(0, 4)
                    accuracy = nn([0] * (numero), lst, 0.01)
                    marker = True
                if 'plus' in i:
                    nuerons_list[int(i[i.index('_')+1:])] += 1
                if 'minus' in i:
                    nuerons_list[int(i[i.index('_')+1:])] -= 1

    return render_template('index.html', numero=numero-2, nuerons_list=nuerons_list, str=str, marker=marker, accuracy=accuracy)


if __name__ == '__main__':
    app.run()

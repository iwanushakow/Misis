import numpy as np
import pandas as pd
import seaborn as sns
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

from sklearn.model_selection import train_test_split

### Шаг 1. Определение функций, которые понадобяться для обучения
# преобразование массива в бинарный вид результатов
def to_one_hot(Y):
    n_col = np.amax(Y) + 1
    binarized = np.zeros((len(Y), n_col))
    for i in range(len(Y)):
        binarized[i, Y[i]] = 1.
    return binarized

# преобразование массива в необходимый вид
def from_one_hot(Y):
    arr = np.zeros((len(Y), 1))

    for i in range(len(Y)):
        l = layer2[i]
        for j in range(len(l)):
            if(l[j] == 1):
                arr[i] = j+1
    return arr

# сигмоида и ее производная
def sigmoid(x):
    return 1/(1+np.exp(-x))

def sigmoid_deriv(x):
    return sigmoid(x)*(1 - sigmoid(x))

# нормализация массива
def normalize(X, axis=-1, order=2):
    l2 = np.atleast_1d(np.linalg.norm(X, order, axis))
    l2[l2 == 0] = 1
    return X / np.expand_dims(l2, axis)

### Шаг 2. Подготовка тренировочных данных
# получения данных из csv файла. укажите здесь путь к файлу Iris.csv
iris_data = pd.read_csv("Iris.csv")
iris_data.head() # расскоментируйте, чтобы посмотреть структуру данных

g = sns.pairplot(iris_data.drop("Id", axis=1), hue="Species")
g.savefig("static/img/output.jpg")





# замена текстовых значений на цифровые
iris_data['Species'].replace(['Iris-setosa', 'Iris-virginica', 'Iris-versicolor'], [0, 1, 2], inplace=True)

# формирование входных данных
columns = ['SepalLengthCm', 'SepalWidthCm', 'PetalLengthCm', 'PetalWidthCm']
x = pd.DataFrame(iris_data, columns=columns)
x = normalize(x.values)

# формирование выходных данных(результатов)
columns = ['Species']
y = pd.DataFrame(iris_data, columns=columns)
y = y.values
y = y.flatten()
y = to_one_hot(y)

# Разделение данных на тренировочные и тестовые
X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.33)


# Шаг 3. Обученние нейронной сети
# присваевание случайных весов
def nuero_network(layers, nuerons, n):
    global X_train, Y_train
    np.random.seed(42)
    print(layers)
    print(nuerons)
    # n - скорость обучения (learning rate)

    #     n1 = 7
    #     n2 = 7
    w_lst = []
    errors = []
    for i in range(len(layers) - 1):
        w_lst.append(2 * np.random.random((nuerons[i], nuerons[i + 1])) - 1)


    # процесс обучения
    for i in range(50000):


        # прямое распространение(feed forward)
        layer0 = X_train
        layers[0] = layer0
        for j in range(1, len(layers)):
            layers[j] = sigmoid(np.dot(layers[j - 1], w_lst[j - 1]))

        # обратное распространение(back propagation) с использованием градиентного спуска
        lst_error_delta = []
        error = y_train - layers[-1]
        delta = sigmoid_deriv(layers[-1]) * error
        lst_error_delta.append([error, delta])

        for j in range(len(layers) - 2, 0, -1):
            error = lst_error_delta[-1][1].dot(w_lst[j].T)
            delta = sigmoid_deriv(layers[j]) * error


            w_lst[j] += layers[j].T.dot(lst_error_delta[-1][1]) * n
            lst_error_delta.append([error, delta])



        error = np.mean(np.abs(lst_error_delta[0][0]))
        errors.append(error)
        accuracy = (1 - error) * 100
        return str(round(accuracy, 2))
from flask import Flask, redirect, render_template, request, send_file
import importlib
from nuero_network import nuero_network as nn

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
app.config['UPLOAD_FOLDER'] = 'works'
dude = importlib.import_module('nuero_network')
numero = 3
@app.route('/', methods=['GET', 'POST'])
def main():
    global numero
    if request.method == 'GET':
        dictionary = dict(request.args)
        if len(dictionary) > 0:
            if 'add' in dictionary.keys():
                numero += 1
            if 'sub' in dictionary.keys() and numero > 2:
                numero -= 1
            if 'start' in dictionary.keys():
                nn([0] * (numero), [7] * (numero - 2), 0.01)


    return render_template('index (2).html', numero=numero)


if __name__ == '__main__':
    app.run()

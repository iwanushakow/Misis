from flask import Flask, redirect, render_template, request, send_file


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
app.config['UPLOAD_FOLDER'] = 'works'

numero = 0
@app.route('/', methods=['GET', 'POST'])
def main():
    global numero
    if request.method == 'GET':
        dictionary = dict(request.args)
        if len(dictionary) > 0:
            print(dictionary)
            if 'plus' in dictionary.keys() and numero < 3:
                numero += 1
            elif 'minus' in dictionary.keys() and numero > 0:
                numero -= 1
            elif 'start' in dictionary.keys():
                print('dfjsdhfksjdh')

    return render_template('index.html', numero=numero)


if __name__ == '__main__':
    app.run()
